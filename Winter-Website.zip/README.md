# Winter — browser-style web app

Winter is a white-and-ice-blue browser-style homepage with a soft space-inspired look, search/address bar, tabs, bookmarks, history, custom shortcuts, sidebar settings, dark mode, and a smiley cursor with an icy particle trail. It includes the Ultraviolet proxy frontend and Node backend.

## Important hosting note
**Deploy this project to Render (or another Node host that supports WebSockets), not as a static Vercel site.** The interface alone can be served statically, but proxy navigation requires the Node/Bare backend and WebSocket upgrades. Vercel's normal static deployment will not run this backend, which is why the site may show a 404 or fail when you try to browse.

## Deploy
1. Upload/commit the contents of this folder to your GitHub repository (the `package.json`, `server.js`, `render.yaml`, and `public/` folder must be at the repository root).
2. Sign in to Render and choose **New → Blueprint** (or create a new Web Service connected to that repository).
3. If using Blueprint, Render reads `render.yaml` automatically. If creating a Web Service manually, use build command `npm install` and start command `npm start`.
4. Wait for the service to finish deploying, then open the `onrender.com` URL Render gives you.

## Run locally
Requires Node.js 18 or newer.

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

## Notes
Proxy compatibility varies: some sites block proxy traffic, require extra browser APIs, or may not load correctly. Use responsibly and follow your host's terms. This project has not been validated against every destination.
